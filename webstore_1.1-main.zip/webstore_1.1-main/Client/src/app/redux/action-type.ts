export enum ActionType {
  userLogin,
  userLogout,
  getUser,
  getProducts,
  getCats,
  getCart,
  getCartItems,
  addItemCart,
  getOrders,
}
