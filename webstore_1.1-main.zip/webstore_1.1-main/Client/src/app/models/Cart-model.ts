export class CartModel {
  public constructor(
    public cartID?: Number,
    public userID?: Number,
    public cartTime?: Date
  ) {}
}
