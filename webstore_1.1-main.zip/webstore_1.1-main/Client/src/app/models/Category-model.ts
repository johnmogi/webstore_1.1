export class CategoryModel {
  public constructor(public catID?: String, public catName?: String) {}
}
